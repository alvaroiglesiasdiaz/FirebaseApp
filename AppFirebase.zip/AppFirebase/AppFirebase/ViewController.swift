//
//  ViewController.swift
//  AppFirebase
//
//  Created by user177270 on 1/18/21.
//

import UIKit
import FirebaseAnalytics
class ViewController: UIViewController {

    @IBAction func CrashApp(_ sender: Any) {
       fatalError()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

